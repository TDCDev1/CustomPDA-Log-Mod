# Custom PDA Logs Mod (EARLY ACCESS)

Provides a custom PDA log system for various Subnautica mods.

- Written in C#
- Works with Subnautica Mod Manager (SMM)
- Built using BepInEx and Nautilus

NexusMods: https://www.nexusmods.com/subnautica/mods/2866
